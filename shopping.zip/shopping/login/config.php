<?php
$conn= mysql_connect("localhost","root","","login");
mysql_set_charset($conn,"utf8");
?>